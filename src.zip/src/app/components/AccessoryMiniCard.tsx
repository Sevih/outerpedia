"use client"

import React from "react"
import Image from "next/image"
import type { AmuletMini } from "@/types/equipment"

const AccessoryMiniCard = ({ accessory }: { accessory: AmuletMini }) => {
  return (
    <div className="w-[110px] flex flex-col items-center text-white">
      <div className="relative w-[96px] h-[96px] rounded bg-[#550000]">
        <Image
          src={`/images/equipment/${accessory.image}`}
          alt={accessory.name}
          width={96}
          height={96}
          className="w-full h-full object-contain"
          unoptimized
        />

        {accessory.effect_icon && (
          <Image
            src={`/images/ui/effect/TI_Icon_UO_Accessary_${accessory.effect_icon}.png`}
            alt="Effect"
            width={20}
            height={20}
            className="absolute top-1 right-1 z-10"
            unoptimized
          />
        )}

        {accessory.class && (
          <Image
            src={`/images/ui/class/${accessory.class.toLowerCase()}.png`}
            alt={accessory.class}
            width={20}
            height={20}
            className="absolute bottom-1 right-1 z-10"
            unoptimized
          />
        )}
      </div>

      <div className="mt-1 text-center text-[12px] leading-tight">
        <p className="font-semibold truncate max-w-[100px]">{accessory.name}</p>
        <p className="text-yellow-300">Main: {accessory.forcedMainStat}</p>
      </div>
    </div>
  )
}

export default AccessoryMiniCard
