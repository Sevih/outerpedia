'use client'
import Link from 'next/link'

export default function WarningBanner() {
  return (
    <>
      <div className="bg-yellow-400 text-black px-2 py-1 rounded-lg shadow-md text-sm text-center border border-yellow-400">
        ⚠️ Character data has been parsed automatically using a custom tool. Errors may exist!
        If you spot something wrong, please report it via our{' '}
        <Link
          href="https://discord.com/invite/ESkqR8ta7y"
          target="_blank"
          className="underline font-semibold hover:text-yellow-200"
        >
          Discord
        </Link>.
      </div>
    </>
  )
}
