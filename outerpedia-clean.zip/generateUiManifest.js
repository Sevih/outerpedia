const fs = require("fs");
const path = require("path");

const baseDir = "./public/images/ui";
const output = path.join(baseDir, "manifest.json");

const excludedDirs = ["effect"];
const validExts = [".webp"];

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);

  for (const file of list) {
    const filepath = path.join(dir, file);
    const stat = fs.statSync(filepath);

    if (stat.isDirectory()) {
      if (!excludedDirs.includes(path.basename(filepath))) {
        results = results.concat(walk(filepath));
      }
    } else if (path.extname(file) === ".webp") {
      const basename = path.basename(file, ".webp");
      const pngPath = path.join(dir, basename + ".png");

      if (fs.existsSync(pngPath)) {
        const relPath = path.relative(baseDir, filepath).replace(/\\/g, "/");
        results.push(relPath);
      }
    }
  }

  return results;
}

const files = walk(baseDir);
fs.writeFileSync(output, JSON.stringify(files, null, 2));
console.log(`✅ manifest.json generated with ${files.length} items (webp with matching png).`);
