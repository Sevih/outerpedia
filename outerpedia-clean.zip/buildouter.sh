#!/bin/bash

# 🧼 Nettoie les anciennes variables
unset NEXT_PUBLIC_APP_VERSION

# 🔁 Recharge la version depuis .env.version
export $(cat .env.version | xargs)

# 🛠 Build complet
npm run build
