#!/bin/bash

# ⛔️ DRY RUN support
DRY_RUN=false
if [[ "$1" == "--dry-run" ]]; then
  DRY_RUN=true
  echo "🔍 Mode DRY RUN activé — aucune commande ne sera réellement exécutée."
fi

# 📦 Vérifie que .env.version existe
if [[ ! -f .env.version ]]; then
  echo "❌ Fichier .env.version introuvable."
  exit 1
fi

# 🔢 Récupère la version actuelle
current_version=$(grep NEXT_PUBLIC_APP_VERSION .env.version | cut -d '=' -f2)
IFS='.' read -r major minor patch <<< "$current_version"

echo "📦 Version actuelle : $current_version"

# 🔧 Demande le type de version
echo "Quel type de version ?"
select choice in "🔧 fix (patch)" "✨ minor" "💥 major"; do
  case $REPLY in
    1) patch=$((patch + 1));;
    2) minor=$((minor + 1)); patch=0;;
    3) major=$((major + 1)); minor=0; patch=0;;
    *) echo "❌ Choix invalide."; exit 1;;
  esac
  break
done

# 🆕 Nouvelle version
new_version="$major.$minor.$patch"
today=$(date +"%Y-%m-%d")
echo "➡️ Nouvelle version : $new_version"

# 📝 Mets à jour .env.version
if ! $DRY_RUN; then
  echo "NEXT_PUBLIC_APP_VERSION=$new_version" > .env.version
else
  echo "[dry-run] Écriture dans .env.version : NEXT_PUBLIC_APP_VERSION=$new_version"
fi

# 🔁 Recharge variable
export NEXT_PUBLIC_APP_VERSION=$new_version

# 🎯 CHOIX DU TYPE DE CHANGELOG
echo "Quel type de mise à jour pour le changelog ?"
select changelog_type in "feature" "fix" "update" "balance"; do
  if [[ -n "$changelog_type" ]]; then break; fi
done

# 📌 Titre de l’entrée changelog
read -p "Titre de l'entrée changelog : " changelog_title
if [[ -z "$changelog_title" ]]; then
  echo "ℹ️ Aucun titre donné — aucune entrée ne sera ajoutée au changelog."
  SKIP_CHANGELOG=true
else
  SKIP_CHANGELOG=false
fi

# 🧾 Contenu changelog (multiligne)
if [[ "$SKIP_CHANGELOG" != true ]]; then
  echo "Écris les points du changelog (termine avec une ligne vide) :"
  changelog_lines=()
  while IFS= read -r line; do
    [[ -z "$line" ]] && break
    changelog_lines+=("$line")
  done

  # 🔧 Formatage contenu TS
  ts_content=""
  for line in "${changelog_lines[@]}"; do
    ts_content+="  - $line"$'\n'
  done

  # 🔧 Formatage contenu MD
  emoji="🚀"
  [[ "$changelog_type" == "fix" ]] && emoji="🐛"
  [[ "$changelog_type" == "update" ]] && emoji="🛠"
  [[ "$changelog_type" == "balance" ]] && emoji="⚖️"

  md_block="## $emoji $changelog_title ($today)"$'\n'
  for line in "${changelog_lines[@]}"; do
    md_block+="- $line"$'\n'
  done

  # ✍️ Mise à jour changelog.ts
if ! $DRY_RUN; then
  tmp_block=$(mktemp)
  {
    echo "  {"
    echo "    date: \"$today\","
    echo "    title: \"$changelog_title\","
    echo "    type: \"$changelog_type\","
    echo "    content: ["
    for line in "${changelog_lines[@]}"; do
      # On échappe les guillemets doubles éventuels dans la ligne
      safe_line=$(echo "$line" | sed 's/"/\\"/g')
      echo "      \"- $safe_line\","
    done
    echo "    ],"
    echo "  },"
  } > "$tmp_block"

  # Insertion dans le tableau export const oldChangelog = [
  awk -v insert="$(cat "$tmp_block")" '
    /export const oldChangelog = \[/ {
      print
      print insert
      next
    }
    { print }
  ' src/data/changelog.ts > "${tmp_block}.final"

  mv "${tmp_block}.final" src/data/changelog.ts
  rm "$tmp_block"
else
  echo "[dry-run] Voici le bloc qui aurait été inséré dans changelog.ts :"
  echo "  {"
  echo "    date: \"$today\","
  echo "    title: \"$changelog_title\","
  echo "    type: \"$changelog_type\","
  echo "    content: ["
  for line in "${changelog_lines[@]}"; do
    safe_line=$(echo "$line" | sed 's/"/\\"/g')
    echo "      \"- $safe_line\","
  done
  echo "    ],"
  echo "  },"
fi



  # ✍️ Mise à jour changelog.md (ajout en haut)
  if ! $DRY_RUN; then
    tmpfile=$(mktemp)
    echo -e "$md_block\n" > "$tmpfile"
    cat changelog.md >> "$tmpfile"
    mv "$tmpfile" changelog.md
  else
    echo "[dry-run] Ajout en haut de changelog.md :"
    echo -e "$md_block"
  fi
fi

# 🧱 Mise à jour package.json
if ! $DRY_RUN; then
  echo "✏️  Mise à jour de package.json avec npm run set-version..."
  npm run set-version "$new_version" || {
    echo "❌ Échec de la mise à jour de version. Commit annulé."
    exit 1
  }
else
  echo "[dry-run] npm run set-version \"$new_version\""
fi

# 🛠 Build complet
if ! $DRY_RUN; then
  echo "🏗 Lancement du build..."
  npm run build || {
    echo "❌ Échec du build. Commit annulé."
    exit 1
  }
else
  echo "[dry-run] npm run build"
fi

# 🔀 Vérifie qu’on est sur master
current_branch=$(git rev-parse --abbrev-ref HEAD)
if [[ "$current_branch" != "master" ]]; then
  echo "⚠️  Tu n'es pas sur la branche master (actuellement sur $current_branch)"
  read -p "Continuer quand même ? (y/N) : " cont
  if [[ "$cont" != "y" && "$cont" != "Y" ]]; then
    echo "Abandon."
    exit 1
  fi
fi

# 📩 Message de commit
read -p "Message de commit : " commit_msg

# 💬 Annonce Discord sauf si refus
read -p "Annoncer sur Discord ? (Y/n) : " announce_discord
announce_discord=${announce_discord:-y}

if [[ "$announce_discord" =~ ^[nN]$ ]]; then
  commit_msg="$commit_msg [no-discord]"
fi

# ✅ Git add, commit, push
if ! $DRY_RUN; then
  git add .
  git commit -m "$commit_msg"
  git push origin master
  echo "✅ Commit et push effectués."
else
  echo "[dry-run] git add ."
  echo "[dry-run] git commit -m \"$commit_msg\""
  echo "[dry-run] git push origin master"
fi

echo "🎉 Fin du script — version $new_version générée."
