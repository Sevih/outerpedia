### FIXME

// FIXME [UI][P2]: Incohérence de comportement au hover des cases (ex: boss ≠ case "All")

### TODO
// TODO [UI][P1] : Ajouter un outil pour ajouter des armes, accessoires, personnage, guide
// TODO [UI][P1] : Ajouter les codes promo actuels
// TODO [Meta][P1]: Générer un état du projet (santé du site, pages manquantes, features à faire)

// TODO [Guide][P2]: Créer un guide général des stats en fonction des sous-classes (cf remarque Kilvanoshei)
// TODO [Guide][P2]: Ajouter un lexique des stats (ex: pénétration, CHD, ACC...) et les rendre cliquables dans les textes

// TODO [UX][P3]: Indiquer dans le texte des objets que certains termes sont des stats → soulignés/cliquables ?
// TODO [Characters][P3] : add preferred gift category in character page

### NOTES
// NOTE [TierList][P3]: Envisager une édition collaborative / votes utilisateur à terme
