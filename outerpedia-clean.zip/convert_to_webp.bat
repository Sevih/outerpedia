@echo off
setlocal enabledelayedexpansion

:: Chemin vers cwebp.exe
set CWEBP="C:\Users\colli\OneDrive\Documents\Projet perso\outerpedia-clean\datamine\pngTowebp\bin\cwebp.exe"

:: Dossier d'entrée
set "INPUT_DIR=public\images"
set "OUTPUT_DIR=public\images"

:: Qualité WebP
set "QUALITY=85"

:: Préfixe à retirer (chemin absolu jusqu'au dossier images)
set "PREFIX=%~dp0%INPUT_DIR%"
if "%PREFIX:~-1%"=="\" set "PREFIX=%PREFIX:~0,-1%"

echo.
echo Conversion des images en .webp...
echo.

for /r "%INPUT_DIR%" %%f in (*.png *.jpg *.jpeg *.gif) do (
    set "SRC=%%f"
    set "WEBP=%%~dpnf.webp"

    set "REL_PATH=%%f"
    call set "REL_PATH=%%REL_PATH:%PREFIX%=%%"
    set "REL_PATH=/images!REL_PATH:%INPUT_DIR%=!"

    if not exist "!WEBP!" (
        echo Conversion de !REL_PATH!
        %CWEBP% -q %QUALITY% "!SRC!" -o "!WEBP!"
    )
)

echo.
echo Conversion terminee !
pause
