const fs = require("fs");
const path = require("path");

const baseDir = "./public/images/characters/boss";
const output = path.join(baseDir, "manifest.json");

const excludedDirs = ["effect"];
const validExts = [".webp"];

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);

  for (const file of list) {
    const filepath = path.join(dir, file);
    const stat = fs.statSync(filepath);
    const relPath = path.relative(baseDir, filepath).replace(/\\/g, "/");

    if (stat.isDirectory()) {
      if (!excludedDirs.includes(path.basename(filepath))) {
        results = results.concat(walk(filepath));
      }
    } else if (validExts.includes(path.extname(file))) {
      results.push(relPath);
    }
  }

  return results;
}

const files = walk(baseDir);
fs.writeFileSync(output, JSON.stringify(files, null, 2));
console.log(`✅ manifest.json generated with ${files.length} items (UI, recursive).`);
