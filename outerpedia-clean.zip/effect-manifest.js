// generateEffectManifest.js
const fs = require("fs");
const path = require("path");

const effectDir = path.join(__dirname, "public/images/ui/effect");
const outputFile = path.join(effectDir, "manifest.json");

const files = fs
  .readdirSync(effectDir)
  .filter((f) => f.endsWith(".webp"))
  .sort();

fs.writeFileSync(outputFile, JSON.stringify(files, null, 2));
console.log(`✅ manifest.json generated with ${files.length} items.`);
